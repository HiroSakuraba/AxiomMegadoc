# AxiomMegaDoc v0.11 Design Document

**Project:** Axiom multilingual pre-pretraining corpus
**Scope:** AxiomScheme, AxiomML, AxiomProlog
**Status:** v0.11 design proposal (replaces v0.10)
**Author:** Benjamin John Schulz, with Claude
**Date:** 2026-05-08
**Supersedes:** axiom_megadoc_v0_10_design.md

---

## 0. What changed from v0.10, and why

The v0.10 plan invoked the Kim–Kotha megadocs paper as the design inspiration for six different megadoc families. On review, only one of those families (latent-diagnostic) actually corresponds to what the paper calls a megadoc; the other five are structured-document training, a related but distinct idea that needs to be motivated on its own terms. The v0.10 plan also missed the paper's central quantitative finding — that megadocs help mostly because they enable longer training under different hyperparameters — and proposed a fixed mixing recipe instead of an empirical sweep. Finally, v0.10's evaluation tasks were all internal to the Axiom corpus and would have measured corpus memorization rather than pre-pretraining quality.

This v0.11 plan addresses those three issues directly.

The framing distinguishes paper-aligned megadocs (one family, latent-diagnostic) from structured contrast/trace documents (everything else). The mixing policy is replaced with a hyperparameter sweep design that mirrors the paper's local-optimality methodology. The evaluation strategy adds at least one external held-out evaluation that doesn't reduce to corpus memorization. The plan is also explicit about the scale problem: at 520 records, the corpus is too small to test the paper's effect at the paper's resolution; the v0.11 milestone therefore measures shortcut-resistance and split-safety properties of megadoc construction rather than pre-pretraining loss reductions, with the loss measurement deferred to a v0.12 milestone after the corpus reaches a meaningful scale.

The schema design from v0.10 — provenance, trust levels, split-safety inheritance — is retained. That part was good and is the load-bearing artifact this plan keeps.

---

## 1. Two foundations, named separately

### 1.1 Paper-aligned: latent-diagnostic megadocs

The Kim–Kotha paper's *latent thoughts* construction splits a real document at G points and generates rationales connecting each prefix to its corresponding suffix, inserting them as `<think>...</think>` blocks. The training signal is: prefix + rationale + suffix is one document, where the rationale renders an implicit reasoning step explicit.

In Axiom this maps cleanly. A canonical source is split at a structurally meaningful point (typically immediately before the recursive case body). A rationale is inserted that articulates the obligation imposed by the annotations and the structural recursion contract. The suffix is then concatenated. The result is a single training document where the implicit obligation between prefix and suffix has been made explicit.

This is paper-aligned. It is the only family in this plan that claims to be.

### 1.2 Newly motivated: structured corpus documents

Three other families are useful but are not what the paper means by megadocs. They are structured training documents that compose multiple records into a single training example. Their motivation is internal to the Axiom corpus design, not paper-derived.

- **Runtime-trace documents** present source + input + lane execution + observed output + expected + diagnostic. The motivation is teaching the source-behavior correspondence in a single training example, exposing the relationship between program text and its observable semantics.

- **Stitched-contrast documents** present a contrast group (valid + invalid + diagnostic + repair) as a single document. The motivation is teaching local proof environments — the relationship between a correct program, a nearby defect, and the rule the defect violates.

- **Cross-language documents** present multiple language renderings of a shared semantic object alongside their language-specific obligations. The motivation is teaching transfer across computation models.

These three are not data augmentation in the paper's sense. They are corpus organization: the same atomic content rearranged to expose different relationships. Whether they help pre-pretraining is an open empirical question. v0.11 does not assume they do.

---

## 2. Design principles

These principles carry forward from v0.10 with sharpened wording.

**Principle 1 — Atomic records remain canonical.** The v0.9C atomic record is the source of truth. A megadoc is a derived view. No megadoc may introduce content that wasn't already validated at the atomic level.

**Principle 2 — Canonical source is never paraphrased.** Code segments are byte-identical to the record's `canonical_source`. Natural-language segments (rationales, task descriptions) may be templated or rephrased but are tagged with `trust_level=explanatory` and never referenced as ground truth in evaluation.

**Principle 3 — Split safety is hereditary.** A megadoc inherits its split assignment from its component records. All records in one megadoc must already share a split. Cross-language megadocs require pre-aligning their components to the same split before construction.

**Principle 4 — Provenance is mandatory.** Every segment carries `provenance` and `trust_level`. Validators reject any megadoc with a segment whose provenance cannot be resolved to a record ID, an extractor function, or a named template.

**Principle 5 — The mixing policy is empirical, not asserted.** Mixing fractions across atomic and megadoc streams are tuned via the same local-optimality search the paper uses, not chosen by intuition.

---

## 3. Schema (carried forward, lightly tightened)

### 3.1 AxiomMegaDoc

```json
{
  "megadoc_id": "string",
  "construction": "latent_diagnostic | runtime_trace | stitched_contrast | cross_language",
  "split": "train | dev | test",
  "split_inheritance": {
    "source_split_keys": ["..."],
    "all_records_same_split": true
  },
  "record_ids": ["..."],
  "contrast_group_ids": ["..."],
  "semantic_object_ids": ["..."],
  "language_set": ["scheme", "ml", "prolog"],
  "segments": [/* MegaDocSegment */],
  "rendered_text": "string",
  "token_estimate": 0,
  "validation": {
    "all_records_same_split": true,
    "all_canonical_sources_byte_equal": true,
    "all_record_refs_resolve": true,
    "no_unchecked_source": true,
    "rationale_template_ids_known": true
  }
}
```

### 3.2 MegaDocSegment

```json
{
  "segment_id": "string",
  "segment_type": "task | source | ast_facts | type_facts | mode_facts | expected_io | runtime_result | invalid_mutation | diagnostic | repair | rationale | cross_language_link",
  "language": "scheme | ml | prolog | mixed | none",
  "record_id": "string | null",
  "rationale_template_id": "string | null",
  "content": "string",
  "provenance": "record | extractor | rationale_template",
  "trust_level": "canonical | checked | extracted | explanatory"
}
```

The `provenance` field is collapsed from v0.10's five values to three:
- `record` — content is byte-copied from a record field
- `extractor` — content is the deterministic output of a named extractor function applied to a record
- `rationale_template` — content is generated by filling a named template with extracted facts

The `trust_level` field has four values:
- `canonical` — byte-identical to canonical source
- `checked` — output of a checker or runtime that has been validated against expected
- `extracted` — output of a structural extractor (AST facts, type facts) that is deterministic given the record
- `explanatory` — natural-language rationale; never referenced as ground truth

### 3.3 SemanticObject (deferred)

The v0.10 plan introduced a `SemanticObject` abstraction binding records across languages. v0.11 defers this. Cross-language megadocs are deferred to v0.12 and require curated semantic mapping that does not currently exist. The `SemanticObject` schema can be designed once that curation is done; designing it now is premature.

---

## 4. v0.11 megadoc families (two only)

### 4.1 latent_diagnostic — paper-aligned

**Construction.** Given a record `r` with a structurally clean canonical source:

1. Split `r.canonical_source` at the boundary immediately before the recursive case body. For Scheme, this is between the base case and the recursive branch of the `if`/`cond`. For ML, between the base case and the recursive case of the `case ... of`. For Prolog, between the base clause and the recursive clause.
2. Generate a rationale by filling a named template with extracted facts. The template is keyed by `(language, family, defect_potential)` and references only fields available in the record.
3. The full segment list is: task header, source prefix, rationale, source suffix, expected I/O, diagnostic (if invalid), repair (if invalid).

**Acceptance gates.**
- Source prefix + suffix concatenated must equal canonical source byte-for-byte.
- Rationale must be filled from a registered template; templates are version-pinned.
- Rationale must reference at least one extracted fact (annotation, base case value, recursive argument); the validator parses the rationale text for the fact tokens and rejects any rationale that doesn't include at least one.

**Why this is buildable now.** The split point is structural and the template registry is small (one template per family-defect class, ~20 templates total). The corpus already has the field structure to support it. No new content needs to be invented.

### 4.2 runtime_trace — independently motivated

**Construction.** Given a valid record `r` whose lane has executed:

1. Header with task description and language.
2. Canonical source (byte-copy from record).
3. Input expression (from `r.semantic`).
4. Lane invocation block: lane name, runtime, exit status.
5. Observed output (from `r.lane_results`).
6. Expected output (from `r.expected_output`).
7. Pass/fail line.

**Acceptance gates.**
- All seven segments present.
- Observed output equals expected (the only valid records in the corpus pass their lanes by construction; this is a sanity check, not a generation parameter).
- Lane runtime field present; if absent, the megadoc is rejected, not synthesized with a placeholder.

**Why this family is useful independent of the paper.** Pre-pretraining benefits from text that explicitly displays the source-behavior correspondence. This is roughly the analogue of "show your work" rather than data augmentation: a model that has seen `(slist_sum0 '(0 1 2))` followed by the literal output `3` learns to associate program text with its output value as a textual relationship, before any natural-text pretraining runs on it. The construction is supported by exactly the runtime-lane infrastructure built in v0.9A–v0.9C.

### 4.3 Deferred to v0.12

- **stitched_contrast** is deferred. The construction is straightforward, but its motivation depends on whether teaching contrast neighborhoods improves downstream pre-pretraining performance, which can only be tested at scales 100×–1000× the current corpus size. v0.11 does not synthesize stitched-contrast megadocs.

- **cross_language** is deferred. It requires a curated `semantic_object_id` mapping across Scheme/ML/Prolog families. Building that mapping is a separate project.

---

## 5. Rationale templates

### 5.1 Template registry

Rationale templates are stored as a versioned registry. Each template has:

```json
{
  "template_id": "string",
  "version": "0.1",
  "language": "scheme | ml | prolog",
  "applies_to_families": ["scheme_list_sum", "scheme_list_product", ...],
  "applies_to_defects": ["wrong_base_case_value", "non_decreasing_recursion", ...],
  "required_facts": ["recursive_annotation", "base_case_value", "recursive_argument_form"],
  "text": "Templated string with {fact_name} placeholders"
}
```

### 5.2 Concrete examples

Template `scheme_structural_recursion_obligation_v01`:

```
The {recursive_annotation} annotation creates an obligation:
every recursive call to {function_name} must apply the function
to a syntactic subterm of {primary_argument}. The base case below
tests {base_predicate} — at this point {primary_argument} is empty
and the function must return a value of type compatible with the
recursion's combining operator.
```

Template `ml_exhaustiveness_obligation_v01`:

```
A total function over {datatype_name} must handle every constructor.
The constructors are {constructor_list}. A pattern match that omits
any of these will fail at run time with Match exception, and the
checker will emit non_exhaustive_pattern.
```

Template `prolog_arithmetic_groundness_v01`:

```
The {is_predicate} predicate evaluates its right-hand argument
arithmetically. Arithmetic evaluation requires every variable in
the expression to be ground at the moment of the call. The mode
declaration {mode_declaration} requires {input_var} to be ground
on entry; after the recursive call binds {output_var}, the
arithmetic step is safe.
```

### 5.3 Validation

The rationale validator parses the generated rationale text for the literal fact tokens (function name, datatype name, mode declaration string) and rejects any rationale that doesn't include all required facts. This protects against rationale drift — the rationale being formally well-typed but semantically about a different program than the source.

---

## 6. Empirical methodology (replaces v0.10 fixed mixing policy)

### 6.1 The mixing question, posed correctly

The question is not "what fraction of training tokens should be megadoc-formatted." The question is: **for a fixed total token budget, which document-format mixture minimizes the relevant evaluation metric, after a local-optimality search over training hyperparameters at each mixture point?**

The paper's methodology answers this by, for each mixture, separately tuning learning rate, weight decay, real-stream epoch count, and synthetic-stream mixing fraction. The optimum is found via local-optimality certification: a point is locally optimal when no single-coordinate move improves loss.

### 6.2 The Axiom analogue

For Axiom, the relevant hyperparameter axes are:
- Atomic-stream epoch count
- Megadoc-stream mixing fraction (as a token-weighted fraction, not document-weighted)
- Per-family megadoc fraction inside the megadoc stream
- Weight decay
- Learning rate

The grid for v0.11:
- Atomic epoch count: {1, 4, 8, 16}
- Megadoc mixing fraction: {0.0, 0.25, 0.50, 0.75}
- Latent-diagnostic vs runtime-trace ratio: {1:0, 1:1, 0:1}
- Weight decay: {0.1, 0.4, 0.8}
- Learning rate: {3e-4, 1e-3, 3e-3}

This is a five-dimensional grid; a full sweep is 4×4×3×3×3 = 432 points. A local-optimality search starting from the v0.9C atomic baseline and performing single-coordinate moves typically certifies in 30–60 evaluations.

### 6.3 Token-weighted mixing

Megadocs are 5–20× longer than atomic records. A document-weighted "25% megadoc" is realistically 60–80% of training tokens. v0.11 uses token-weighted mixing throughout: the megadoc fraction is the fraction of *training tokens* coming from megadoc documents, computed after rendering and tokenization, not before.

---

## 7. External evaluation

The v0.10 plan evaluated megadoc training using corpus-internal tasks (atomic diagnostic, megadoc comprehension, repair prediction). At Axiom's scale, a small model can memorize the corpus, so these tasks measure memorization rather than pre-pretraining quality.

v0.11 adds at least one external evaluation that is held out from the corpus.

### 7.1 Continued-pretraining loss

The primary external evaluation is the paper's own metric, adapted: train two small models for the same compute budget — one on atomic-only Axiom, one on the v0.11 mixture. Then continue both on a held-out natural-text corpus (DCLM subset, 50M tokens), measure validation loss trajectories on a held-out web subset, and compute relative data efficiency.

This is exactly the experimental shape from the paper. The hypothesis is that the megadoc-augmented pre-pretraining model reaches a given validation loss with fewer continued-pretraining tokens than the atomic-only baseline.

### 7.2 Reasoning-benchmark transfer

The secondary evaluation is downstream benchmark accuracy after continued pretraining, on PIQA, SciQ, ARC-Easy, and the procedurally-generated reasoning subset of MMLU.

### 7.3 Internal eval as supplementary

The corpus-internal evaluations from v0.10 are retained as supplementary signals but not as primary metrics. They report whether the model has internalized corpus content; the external metrics report whether that internalization transfers.

---

## 8. Honest scale discussion

At 520 records, the Axiom corpus is too small to test the paper's effect at the paper's resolution. The paper used 200M tokens of real web text and up to 32 generations per document, totaling several billion tokens of training data. Axiom at v0.9C is ~50K tokens.

The v0.11 milestone therefore does not claim to test the megadoc hypothesis empirically. It claims to:
1. Build the latent-diagnostic and runtime-trace constructions correctly
2. Validate split-safety and shortcut-resistance properties of the constructions
3. Set up the experimental machinery (hyperparameter sweep, external eval) that will run once the corpus reaches v1.0 scale (target: 5K records, ≥500K tokens)

The empirical megadoc-vs-atomic test is deferred to v0.12, after corpus scaling. The v0.11 milestone is infrastructure, not a positive result.

---

## 9. Anti-shortcut analysis (sharpened)

The v0.10 plan listed plausible shortcuts and proposed mitigations. v0.11 specifies which shortcuts the validator must check and what failing each check means.

**Position-of-defect shortcut.** If `invalid_mutation` segments always appear at a fixed position (e.g., segment 5 of 7), a model can learn "segment 5 is the invalid one" without reading content. Mitigation: the renderer randomizes section order within an allowed permutation set defined per construction type. Validator: NMI(is_valid, segment_index_of_invalid_section) < 0.10 over the rendered bundle.

**Section-presence shortcut.** If `repair` segments appear only in megadocs derived from invalid records, presence-of-repair predicts invalidity. Mitigation: a fraction (≥20%) of valid-only megadocs include a `no_repair_needed` segment with explanatory content. Validator: NMI(label, has_repair_segment) < 0.10.

**Rationale-template shortcut.** If `rationale_template_id` correlates with label, the template ID becomes a shortcut feature. Mitigation: the same template is used across both valid and invalid records of a family wherever applicable. Validator: NMI(label, rationale_template_id) < 0.05.

**Construction-type shortcut.** The construction type may correlate with diagnostic class. If runtime-trace megadocs disproportionately appear for valid records (which they must, since invalids don't execute), this is by design and not a shortcut — but the model should not be able to predict the diagnostic from construction type alone above baseline. Validator: NMI(diagnostic_code, construction_type) < 0.20.

These are gates; failures block release.

---

## 10. Implementation plan

### 10.1 Directory layout

```
axiom_megadoc/
  __init__.py
  schema.py
  rationale_templates/
    __init__.py
    registry.py
    scheme_templates.py
    ml_templates.py
    prolog_templates.py
  builders/
    latent_diagnostic.py
    runtime_trace.py
  extractors/
    scheme_facts.py
    ml_facts.py
    prolog_facts.py
  validators/
    validate_segments.py
    validate_split_safety.py
    validate_canonical_source.py
    validate_rationale_facts.py
    validate_shortcuts.py
  render/
    text_render.py
    parse_rendered.py
  tests/
    test_schema_roundtrip.py
    test_latent_diagnostic_split_byte_equal.py
    test_runtime_trace_lane_present.py
    test_rationale_fact_coverage.py
    test_no_unchecked_source.py
    test_render_parse_roundtrip.py
```

### 10.2 v0.11 deliverables (concrete)

1. Schema implementation with full validation.
2. Three rationale templates: structural-recursion-obligation (Scheme), exhaustiveness-obligation (ML), arithmetic-groundness (Prolog).
3. Latent-diagnostic builder. Generates ≤1 megadoc per valid record where the family has a registered template.
4. Runtime-trace builder. Generates exactly 1 megadoc per valid record with a successful lane execution.
5. Text renderer with versioned section delimiter format.
6. Round-trip parser that reconstructs the segment list from rendered text.
7. All five validators.
8. Acceptance gate: every test passes; every shortcut NMI under threshold; every rendered megadoc round-trips through parse–render with byte equality.

### 10.3 What is NOT in v0.11

- No stitched_contrast construction.
- No cross_language construction.
- No SemanticObject schema.
- No ACV references.
- No claims about pre-pretraining loss improvements.
- No external evaluation runs (machinery is set up; runs happen at v0.12 when the corpus has scaled).

---

## 11. Risks and mitigations (focused)

**Risk: rationale drift.** A rationale generated for record A could be syntactically valid for record B's source. Mitigation: rationale validator parses for required-fact tokens and rejects rationales that don't include all of them. Tested by a deliberately-mismatched rationale corpus in `tests/test_rationale_fact_coverage.py`.

**Risk: render-parse asymmetry.** A megadoc that renders correctly but doesn't parse back to its segment list creates a silent corpus inconsistency. Mitigation: every rendered megadoc must round-trip; the validator runs render → parse → compare on every megadoc before release.

**Risk: split-safety violation through cross-record reference.** A megadoc segment could textually mention a record ID from a different split, leaking information. Mitigation: the `record_ids` field is the closure; any record ID appearing in any segment text must be in `record_ids`, and `record_ids` must be split-homogeneous.

**Risk: token-weighted vs document-weighted confusion.** Megadocs are much longer than atomic records, so document-counts and token-counts give very different mixture fractions. Mitigation: all mixture reports are token-weighted; document-counts are reported separately and never used for hyperparameter selection.

---

## 12. Bottom line

The v0.11 plan is narrower than v0.10 because v0.10 promised more than the paper actually supports. The two buildable v0.11 constructions are latent-diagnostic (paper-aligned) and runtime-trace (independently motivated). Stitched-contrast and cross-language are deferred until corpus scale supports their evaluation and curatorial mappings exist. The mixing policy is empirical, the evaluation is external, and the scale honesty is explicit: v0.11 is infrastructure, not a positive empirical result.

The good parts of v0.10 — the schema, the trust-level taxonomy, the split-safety inheritance — carry forward intact. They were the load-bearing parts. The framing has been corrected.
