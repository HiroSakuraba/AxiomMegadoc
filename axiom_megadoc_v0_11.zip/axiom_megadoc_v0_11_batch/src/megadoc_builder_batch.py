"""AxiomMegaDoc v0.11 multi-language builder against v0.9D corpus.

Builds latent_diagnostic and runtime_trace megadocs for each of the three
Axiom languages: Scheme, ML, Prolog.  Reads from the v0.9D ledger directly
(no live generation).  Uses installed runtimes (guile, mlton, swipl) for
runtime_trace executions.

The v0.11 schema and validation contract is identical across languages.  The
per-language differences are confined to:

  * The structural split point used in latent_diagnostic
  * The fact-extractor function
  * The rationale template registry
  * The execution harness for runtime_trace
"""
from __future__ import annotations
import hashlib
import json
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

V09D_LEDGER = Path(__file__).parent.parent / 'source-corpus' / 'axiom_v09d_ledger.jsonl'


# ── load records ──────────────────────────────────────────────────────────────

def load_records() -> list[dict]:
    return [json.loads(l) for l in V09D_LEDGER.read_text().splitlines() if l.strip()]


# ── megadoc dataclasses ───────────────────────────────────────────────────────

@dataclass
class MegaDocSegment:
    segment_id: str
    segment_type: str
    language: str
    record_id: str | None
    rationale_template_id: str | None
    content: str
    provenance: str
    trust_level: str


@dataclass
class AxiomMegaDoc:
    megadoc_id: str
    construction: str
    split: str
    record_ids: list[str]
    contrast_group_ids: list[str]
    language_set: list[str]
    segments: list[MegaDocSegment]
    rendered_text: str = ''
    token_estimate: int = 0
    validation: dict = field(default_factory=dict)


# ── rationale template registry (multi-language) ──────────────────────────────

RATIONALE_TEMPLATES: dict[str, dict[str, Any]] = {
    'scheme_structural_recursion_obligation_v01': {
        'language': 'scheme',
        'required_facts': [
            'function_name', 'primary_argument',
            'recursive_annotation', 'base_predicate',
        ],
        'text': (
            'The {recursive_annotation} annotation creates an obligation: every '
            'recursive call to {function_name} must apply the function to a '
            'syntactic subterm of {primary_argument}. The base case below '
            'tests {base_predicate} — at the moment this branch fires, '
            '{primary_argument} is empty and {function_name} must return the '
            'identity element of the combining operator below.'
        ),
    },
    'ml_exhaustive_pattern_obligation_v01': {
        'language': 'ml',
        'required_facts': [
            'function_name', 'parameter_type', 'base_pattern', 'recursive_pattern',
        ],
        'text': (
            'A total function over {parameter_type} must handle every constructor. '
            'The two cases below are {base_pattern} for the empty list and '
            '{recursive_pattern} for a non-empty list. MLton enforces this '
            'exhaustiveness statically; a missing case is reported as '
            'non_exhaustive_pattern. The value returned in {base_pattern} '
            'is the identity element of the combining operator used in '
            '{recursive_pattern}, where {function_name} recurses on the tail.'
        ),
    },
    'prolog_difference_list_obligation_v01': {
        'language': 'prolog',
        'required_facts': [
            'predicate_name', 'mode_declaration',
            'base_clause_pattern', 'recursive_clause_pattern',
        ],
        'text': (
            'The mode declaration {mode_declaration} fixes which arguments must '
            'be ground on entry to {predicate_name}. The base clause '
            'pattern {base_clause_pattern} handles the terminal case where the '
            'list-structured input has been fully consumed. The recursive '
            'clause {recursive_clause_pattern} matches one element off the '
            'head and recurses on the tail. With the cut excluded and occurs '
            'check enabled, this gives a unique proof tree per input.'
        ),
    },
}


def fill_rationale(template_id: str, facts: dict[str, str]) -> str:
    spec = RATIONALE_TEMPLATES[template_id]
    missing = [k for k in spec['required_facts'] if k not in facts]
    if missing:
        raise ValueError(f'template {template_id} missing facts: {missing}')
    return spec['text'].format(**facts)


def validate_rationale_facts(rationale: str, required_facts: list[str],
                             facts: dict[str, str]) -> bool:
    return all(facts[k] in rationale for k in required_facts)


# ── per-language extractors and split points ──────────────────────────────────

def split_scheme(canonical_source: str) -> tuple[str, str]:
    m = re.search(r'\(if \(null\? [^)]+\)\n(\s+)([^\n]+)\n', canonical_source)
    if not m:
        raise ValueError('no recognisable (if (null? ...) ...) base case')
    return canonical_source[:m.end()], canonical_source[m.end():]


def extract_scheme_facts(record: dict) -> dict[str, str]:
    src = record['canonical_source']
    facts: dict[str, str] = {}
    m = re.search(r'\(define \(([a-z][A-Za-z0-9_]*)\s+(\w+)', src)
    if m:
        facts['function_name'] = m.group(1)
        facts['primary_argument'] = m.group(2)
    for ann in ('(@recursive structural)', '(@recursive none)'):
        if ann in src:
            facts['recursive_annotation'] = ann
            break
    if '(null?' in src:
        facts['base_predicate'] = '(null? xs)'
    return facts


def split_ml(canonical_source: str) -> tuple[str, str]:
    """Split an ML case-of between the base pattern and the recursive pattern.

    The boundary is just after the `=> BASE_EXPR ` and before `| RECURSIVE_PATTERN`.
    """
    m = re.search(r'(\[\]\s*=>\s*[^|]+)\|\s*(h::t|h\s*::\s*t)', canonical_source)
    if not m:
        raise ValueError('no recognisable [] => ... | h::t pattern')
    boundary = m.start(2) - 2  # back up over `| `
    return canonical_source[:boundary], canonical_source[boundary:]


def extract_ml_facts(record: dict) -> dict[str, str]:
    src = record['canonical_source']
    facts: dict[str, str] = {}
    m = re.search(r'fun\s+([a-z][A-Za-z0-9_]*)\s*\(\s*\w+\s*:\s*([^)]+?)\s*\)', src)
    if m:
        facts['function_name'] = m.group(1)
        facts['parameter_type'] = m.group(2).strip()
    m2 = re.search(r'(\[\]\s*=>\s*[^|]+?)\s*\|', src)
    if m2:
        facts['base_pattern'] = m2.group(1).strip()
    m3 = re.search(r'\|\s*(h::t\s*=>[^$]+?)$', src.replace('\n', ' '))
    if m3:
        facts['recursive_pattern'] = m3.group(1).strip()
    return facts


def split_prolog(canonical_source: str) -> tuple[str, str]:
    """Split a Prolog source between the base clause and the recursive clause.

    The boundary is the newline immediately after the base clause's period.
    """
    lines = canonical_source.split('\n')
    out_prefix: list[str] = []
    out_suffix: list[str] = []
    seen_recursive = False
    for line in lines:
        if not seen_recursive and ' :- ' in line:
            seen_recursive = True
        if seen_recursive:
            out_suffix.append(line)
        else:
            out_prefix.append(line)
    if not out_suffix:
        raise ValueError('no recursive clause found')
    prefix = '\n'.join(out_prefix) + '\n'
    suffix = '\n'.join(out_suffix)
    if prefix + suffix != canonical_source:
        # Recover trailing newline if any
        if canonical_source.endswith('\n') and not suffix.endswith('\n'):
            suffix += '\n'
        if prefix + suffix != canonical_source:
            raise ValueError(
                f'prolog split not byte-equal: '
                f'len_prefix={len(prefix)} len_suffix={len(suffix)} '
                f'len_total={len(canonical_source)}'
            )
    return prefix, suffix


def extract_prolog_facts(record: dict) -> dict[str, str]:
    src = record['canonical_source']
    facts: dict[str, str] = {}
    m = re.search(r'^([a-z][A-Za-z0-9_]*)\b', src.lstrip('%! \n'))
    if m:
        facts['predicate_name'] = m.group(1)
    m2 = re.search(r'%!\s*([^\n]+)', src)
    if m2:
        facts['mode_declaration'] = '%! ' + m2.group(1).strip()
    lines = [l for l in src.split('\n') if l and not l.startswith('%')]
    if lines:
        facts['base_clause_pattern'] = lines[0]
        for line in lines[1:]:
            if ' :- ' in line:
                facts['recursive_clause_pattern'] = line
                break
    return facts


# ── repair text registry ──────────────────────────────────────────────────────

REPAIR_TEXT = {
    # Scheme
    'missing_base_case':       'Replace `#f` with `(null? xs)` — the base '
                                'predicate of structural recursion on lists.',
    'banned_mutation':         'Remove the `(set! ...)` form. AxiomScheme bans '
                                'mutation; effect annotation is `pure`.',
    'bad_effect_annotation':   'Restore the matching effect annotation.',
    'non_decreasing_recursion':'Pass `(cdr xs)` (Scheme) or `t` (ML) or the '
                                'tail variable (Prolog) so the recursion '
                                'reaches a smaller term.',
    'bad_recursive_annotation':'Restore `(@recursive structural)` — the '
                                'function recurses on a strict subterm.',
    'bad_resource_annotation': 'Restore the matching resource annotation.',
    'semantic_mismatch':       'Restore the original combining operator and '
                                'base value to match the family semantic spec.',

    # ML
    'wrong_base_case_value':   'Set the empty-list case to the identity of the '
                                'combining operator (0 for +, 1 for *).',
    'non_exhaustive_pattern':  'Add the missing constructor case.',
    'type_signature_mismatch': 'Restore the result-type annotation that matches '
                                'the function body.',
    'wrong_arithmetic_op':     'Restore the combining operator implied by the '
                                'family semantic spec.',
    'banned_ref':              'Remove the `ref`-cell binding. AxiomML bans '
                                'mutable references.',

    # Prolog
    'semantic_expected_mismatch':
                                'Restore the predicate name so the query in the '
                                'driver resolves correctly.',
    'missing_mode_declaration':
                                'Restore the `%! name(+/-args)` line — the mode '
                                'declaration is mandatory in AxiomProlog.',
    'banned_cut':               'Remove the cut. AxiomProlog excludes the cut '
                                'to preserve the logical reading of clauses.',
    'wrong_arithmetic_step':    'Restore the `N is N0+1` step to match the '
                                'family arithmetic recurrence.',
    'wrong_token_pattern':      'Restore the original list-head pattern.',
    'extra_clause':             'Remove the spurious clause that admits '
                                'unintended solutions.',
    'bad_mode_declaration':     'Restore the proper `%!` prefix and argument '
                                'modes.',
    'banned_assert':            'Remove the `assert/retract` use. AxiomProlog '
                                'bans dynamic database mutation.',
    'unsafe_negation':          'Replace `\\+ G` with an equivalent that does '
                                'not depend on negation-as-failure with '
                                'unground arguments.',
}


# ── builders: latent_diagnostic, per language ─────────────────────────────────

def _build_latent_diagnostic_common(
    valid: dict, invalid: dict, *,
    language_code: str,
    code_block_marker: str,
    template_id: str,
    facts: dict[str, str],
    prefix: str, suffix: str,
    task_description: str,
    expected_io_block: str,
) -> AxiomMegaDoc:
    rationale = fill_rationale(template_id, facts)
    spec = RATIONALE_TEMPLATES[template_id]
    if not validate_rationale_facts(rationale, spec['required_facts'], facts):
        raise ValueError(f'rationale fact validation failed for {template_id}')

    repair = REPAIR_TEXT.get(
        invalid['defect_kind'], 'See diagnostic for the required correction.'
    )

    segments = [
        MegaDocSegment('S1', 'task', language_code, None, None,
                       task_description, 'rationale_template', 'explanatory'),
        MegaDocSegment('S2', 'source', language_code,
                       valid['record_id'], None, prefix.rstrip('\n'),
                       'record', 'canonical'),
        MegaDocSegment('S3', 'rationale', 'none',
                       valid['record_id'], template_id, rationale,
                       'rationale_template', 'explanatory'),
        MegaDocSegment('S4', 'source', language_code,
                       valid['record_id'], None, suffix.rstrip('\n'),
                       'record', 'canonical'),
        MegaDocSegment('S5', 'expected_io', 'none',
                       valid['record_id'], None, expected_io_block,
                       'extractor', 'extracted'),
        MegaDocSegment('S6', 'invalid_mutation', language_code,
                       invalid['record_id'], None, invalid['canonical_source'],
                       'record', 'canonical'),
        MegaDocSegment('S7', 'diagnostic', 'none',
                       invalid['record_id'], None,
                       ', '.join(invalid['diagnostic_codes']),
                       'record', 'checked'),
        MegaDocSegment('S8', 'repair', 'none',
                       invalid['record_id'], None, repair,
                       'rationale_template', 'explanatory'),
    ]

    md_id = 'md_' + hashlib.sha256(
        f'latent_diagnostic:{valid["contrast_group_id"]}'.encode()
    ).hexdigest()[:12]

    # Per-language byte-equality reassembly
    reassembled = segments[1].content + ('\n' if suffix.startswith('\n') is False
                                          and not segments[1].content.endswith('\n')
                                          else '') + segments[3].content
    # Simpler: try a few reassembly options
    reassembly_ok = False
    for sep in ('', '\n'):
        if segments[1].content + sep + segments[3].content == valid['canonical_source']:
            reassembly_ok = True
            break

    return AxiomMegaDoc(
        megadoc_id=md_id, construction='latent_diagnostic',
        split=valid.get('split', 'train'),
        record_ids=[valid['record_id'], invalid['record_id']],
        contrast_group_ids=[valid['contrast_group_id']],
        language_set=[language_code], segments=segments,
        validation={
            'all_records_same_split':
                valid.get('split') == invalid.get('split'),
            'all_canonical_sources_byte_equal': reassembly_ok,
            'all_record_refs_resolve': True,
            'no_unchecked_source':
                all(s.trust_level == 'canonical'
                    for s in segments
                    if s.segment_type in ('source', 'invalid_mutation')),
            'rationale_template_ids_known':
                all((s.rationale_template_id in RATIONALE_TEMPLATES)
                    or (s.rationale_template_id is None)
                    for s in segments),
        },
    )


def build_latent_diagnostic_scheme(valid: dict, invalid: dict) -> AxiomMegaDoc:
    if valid['contrast_group_id'] != invalid['contrast_group_id']:
        raise ValueError('contrast group mismatch')
    facts = extract_scheme_facts(valid)
    prefix, suffix = split_scheme(valid['canonical_source'])
    expected_str = json.dumps(valid['expected_output']['value'],
                              separators=(',', ':'))
    return _build_latent_diagnostic_common(
        valid, invalid,
        language_code='scheme', code_block_marker='scheme',
        template_id='scheme_structural_recursion_obligation_v01',
        facts=facts, prefix=prefix, suffix=suffix,
        task_description=(
            f'Compute the sum of a list of exact integers using structural '
            f'recursion in AxiomScheme. The function is {facts["function_name"]}.'
        ),
        expected_io_block=(
            f'input: {valid["semantic"]["input_expr"]}\n'
            f'expected_value_json: {expected_str}'
        ),
    )


def build_latent_diagnostic_ml(valid: dict, invalid: dict) -> AxiomMegaDoc:
    if valid['contrast_group_id'] != invalid['contrast_group_id']:
        raise ValueError('contrast group mismatch')
    facts = extract_ml_facts(valid)
    prefix, suffix = split_ml(valid['canonical_source'])
    expected_str = json.dumps(valid['expected_output']['value'],
                              separators=(',', ':'))
    return _build_latent_diagnostic_common(
        valid, invalid,
        language_code='ml', code_block_marker='sml',
        template_id='ml_exhaustive_pattern_obligation_v01',
        facts=facts, prefix=prefix, suffix=suffix,
        task_description=(
            f'Compute the sum of an int list in AxiomML via exhaustive '
            f'pattern matching. The function is {facts["function_name"]}.'
        ),
        expected_io_block=(
            f'input: {valid["semantic"]["input"]}\n'
            f'expected_value_json: {expected_str}'
        ),
    )


def build_latent_diagnostic_prolog(valid: dict, invalid: dict) -> AxiomMegaDoc:
    if valid['contrast_group_id'] != invalid['contrast_group_id']:
        raise ValueError('contrast group mismatch')
    facts = extract_prolog_facts(valid)
    prefix, suffix = split_prolog(valid['canonical_source'])
    if 'solutions' in valid['expected_output']:
        expected_blob = json.dumps(valid['expected_output']['solutions'],
                                    separators=(',', ':'))
        expected_io = (f'query: {valid["semantic"]["query"]}\n'
                       f'expected_solutions_json: {expected_blob}')
    else:
        expected_io = json.dumps(valid['expected_output'])
    return _build_latent_diagnostic_common(
        valid, invalid,
        language_code='prolog', code_block_marker='prolog',
        template_id='prolog_difference_list_obligation_v01',
        facts=facts, prefix=prefix, suffix=suffix,
        task_description=(
            f'Append two lists using structural recursion on the first list. '
            f'The predicate is {facts["predicate_name"]}.'
        ),
        expected_io_block=expected_io,
    )


# ── runtime_trace, per language ───────────────────────────────────────────────

def run_scheme(record: dict) -> dict:
    if not shutil.which('guile'):
        return {'status': 'skipped', 'reason': 'guile_not_on_path'}
    src = record['canonical_source']
    stripped = re.sub(
        r'\(@(?:effect|resource|recursive|higher-order)[^)]*\)\s*', '', src
    )
    entry = record['semantic']['entry']
    inp = record['semantic']['input_expr']
    prog = stripped + f'\n(write ({entry} {inp}))\n(newline)\n'
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / 'prog.scm'; p.write_text(prog)
        proc = subprocess.run(['guile', '--no-auto-compile', str(p)],
                              capture_output=True, text=True, timeout=5)
    if proc.returncode != 0:
        return {'status': 'fail', 'stderr': proc.stderr[-400:]}
    return {'status': 'pass', 'stdout': proc.stdout.strip()}


def run_ml(record: dict) -> dict:
    if not shutil.which('mlton'):
        return {'status': 'skipped', 'reason': 'mlton_not_on_path'}
    src = record['canonical_source']
    # Infer function name, input, and result type from the record
    m = re.search(r'fun\s+([a-z][A-Za-z0-9_]*)', src)
    if not m: return {'status': 'skipped', 'reason': 'cannot_infer_function'}
    fn = m.group(1)
    inp = record['semantic']['input']
    # Result type: read the `: TYPE =` annotation
    mt = re.search(r'\)\s*:\s*((?:int|bool|string)(?:\s+(?:list|option))?)\s*=', src)
    if not mt: return {'status': 'skipped', 'reason': 'cannot_infer_result_type'}
    rt = mt.group(1).strip()
    if rt == 'int':
        printer = f'Int.toString ({fn} {inp})'
    elif rt == 'bool':
        printer = f'Bool.toString ({fn} {inp})'
    elif rt == 'int list':
        printer = (f'"[" ^ String.concatWith "," '
                   f'(List.map Int.toString ({fn} {inp})) ^ "]"')
    elif rt == 'int option':
        printer = (f'(case ({fn} {inp}) of '
                   f'NONE => "NONE" | SOME x => "SOME " ^ Int.toString x)')
    else:
        return {'status': 'skipped', 'reason': f'unsupported_type_{rt}'}
    harness = src + f'\nval _ = print ({printer} ^ String.str (chr 10))\n'
    with tempfile.TemporaryDirectory() as td:
        s = Path(td) / 'm.sml'; b = Path(td) / 'm'
        s.write_text(harness)
        c = subprocess.run(['mlton', '-output', str(b), str(s)],
                           capture_output=True, text=True, timeout=30)
        if c.returncode != 0:
            return {'status': 'fail', 'stderr': c.stderr[-400:], 'phase': 'compile'}
        r = subprocess.run([str(b)], capture_output=True, text=True, timeout=5)
    if r.returncode != 0:
        return {'status': 'fail', 'stderr': r.stderr[-400:], 'phase': 'run'}
    return {'status': 'pass', 'stdout': r.stdout.strip()}


def run_prolog(record: dict) -> dict:
    if not shutil.which('swipl'):
        return {'status': 'skipped', 'reason': 'swipl_not_on_path'}
    query = record['semantic']['query']
    src = record['canonical_source']
    # Output variables: uppercase tokens in the query
    ovars = sorted(set(re.findall(r'\b([A-Z][A-Za-z0-9_]*)\b', query)))
    if not ovars:
        driver = (
            ':- initialization(main, main).\n'
            'main :- set_prolog_flag(occurs_check, true), '
            f'( {query} -> writeln(\'__SUCCESS__\') ; writeln(\'__FAIL__\') ), '
            'halt.\n'
        )
    else:
        tup = '-'.join(ovars)
        emit = ',\n           '.join(
            f"(write('{v}='), write_canonical({v}), nl)" for v in ovars)
        driver = (
            ':- initialization(main, main).\n'
            'main :-\n'
            '    set_prolog_flag(occurs_check, true),\n'
            f'    findall({tup}, ({query}), Sols__),\n'
            '    length(Sols__, __Count__),\n'
            '    writeln(__Count__),\n'
            f'    forall(member({tup}, Sols__),\n'
            f'           ({emit},\n'
            "            writeln('---'))),\n"
            '    halt.\n'
        )
    program = src.rstrip() + '\n\n' + driver
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / 'prog.pl'; p.write_text(program)
        proc = subprocess.run(['swipl', '-q', str(p)],
                              capture_output=True, text=True, timeout=5)
    if proc.returncode != 0:
        return {'status': 'fail', 'stderr': proc.stderr[-400:]}
    return {'status': 'pass', 'stdout': proc.stdout.strip()}


def build_runtime_trace(record: dict, language_code: str,
                        execute_fn) -> AxiomMegaDoc:
    if not record['is_valid']:
        raise ValueError('runtime_trace requires a valid record')
    lane = execute_fn(record)
    if lane.get('status') != 'pass':
        raise RuntimeError(f'lane did not pass: {lane}')

    expected = record['expected_output']
    if 'value' in expected:
        expected_json = expected['value']
    else:
        expected_json = expected.get('solutions', expected)
    expected_str = json.dumps(expected_json, separators=(',', ':'))

    semantic = record['semantic']
    if language_code == 'scheme':
        invocation = f'function_call: ({semantic["entry"]} {semantic["input_expr"]})'
        io_block = f'input_expr: {semantic["input_expr"]}\n{invocation}'
    elif language_code == 'ml':
        io_block = (f'input: {semantic["input"]}\n'
                    f'compilation: mlton')
    elif language_code == 'prolog':
        io_block = (f'query: {semantic["query"]}\n'
                    f'driver: findall + write_canonical')
    else:
        io_block = json.dumps(semantic)

    runtime_block = (f'lane: {language_code}\n'
                     f'status: pass\n'
                     f'stdout: {lane["stdout"]}\n'
                     f'expected_value_json: {expected_str}')

    task_text = {
        'scheme':  'Execute the AxiomScheme function on a concrete input. Lane: Guile.',
        'ml':      'Compile and run the AxiomML function on a concrete input. Lane: MLton.',
        'prolog':  'Resolve the AxiomProlog query and collect all solutions. Lane: SWI-Prolog.',
    }[language_code]

    segments = [
        MegaDocSegment('S1', 'task', language_code, None, None,
                       task_text, 'rationale_template', 'explanatory'),
        MegaDocSegment('S2', 'source', language_code,
                       record['record_id'], None, record['canonical_source'],
                       'record', 'canonical'),
        MegaDocSegment('S3', 'expected_io', 'none',
                       record['record_id'], None, io_block,
                       'extractor', 'extracted'),
        MegaDocSegment('S4', 'runtime_result', 'none',
                       record['record_id'], None, runtime_block,
                       'extractor', 'checked'),
    ]
    md_id = 'md_' + hashlib.sha256(
        f'runtime_trace:{record["record_id"]}'.encode()).hexdigest()[:12]
    return AxiomMegaDoc(
        megadoc_id=md_id, construction='runtime_trace',
        split=record.get('split', 'train'),
        record_ids=[record['record_id']],
        contrast_group_ids=[record['contrast_group_id']],
        language_set=[language_code], segments=segments,
        validation={
            'all_records_same_split': True,
            'all_canonical_sources_byte_equal':
                segments[1].content == record['canonical_source'],
            'all_record_refs_resolve': True,
            'no_unchecked_source': True,
            'rationale_template_ids_known': True,
        },
    )


# ── render and round-trip parse ───────────────────────────────────────────────

_CODE_FENCE = {'scheme': 'scheme', 'ml': 'sml', 'prolog': 'prolog'}


def render_megadoc(md: AxiomMegaDoc) -> str:
    lines = [
        f'<AXIOM_MEGADOC id="{md.megadoc_id}" construction="{md.construction}" '
        f'split="{md.split}" languages="{",".join(md.language_set)}" '
        f'corpus="v0.9D">',
        '',
    ]
    for seg in md.segments:
        attrs = (f'type="{seg.segment_type}" trust="{seg.trust_level}" '
                 f'provenance="{seg.provenance}"')
        if seg.record_id:
            attrs += f' record_id="{seg.record_id}"'
        if seg.rationale_template_id:
            attrs += f' template="{seg.rationale_template_id}"'
        lines.append(f'<SEGMENT {attrs}>')
        is_code = (seg.language in _CODE_FENCE
                   and seg.segment_type in ('source', 'invalid_mutation'))
        if is_code:
            lines.append(f'```{_CODE_FENCE[seg.language]}')
            lines.append(seg.content)
            lines.append('```')
        else:
            lines.append(seg.content)
        lines.append('</SEGMENT>')
        lines.append('')
    lines.append('</AXIOM_MEGADOC>')
    text = '\n'.join(lines)
    md.rendered_text = text
    md.token_estimate = len(text.split())
    return text


_SEG_OPEN = re.compile(r'<SEGMENT ([^>]+)>')
_SEG_ATTR = re.compile(r'(\w+)="([^"]*)"')

def parse_rendered(text: str) -> list[dict]:
    segments: list[dict] = []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        m = _SEG_OPEN.match(lines[i])
        if not m:
            i += 1; continue
        attrs = dict(_SEG_ATTR.findall(m.group(1)))
        body: list[str] = []
        i += 1
        while i < len(lines) and lines[i] != '</SEGMENT>':
            body.append(lines[i]); i += 1
        if body and body[0].startswith('```') and body[-1] == '```':
            body = body[1:-1]
        segments.append({'attrs': attrs, 'content': '\n'.join(body)})
    return segments


# ── orchestration ─────────────────────────────────────────────────────────────

def build_all(out_dir: Path) -> dict:
    records = load_records()
    by_id = {r['record_id']: r for r in records}

    # Selected representatives per language
    scheme_valid = next(r for r in records
                        if r['record_id'] == 'axiom_scheme:scheme_list_sum:9:valid:none')
    scheme_invalid = next(
        r for r in records
        if r['contrast_group_id'] == scheme_valid['contrast_group_id']
        and not r['is_valid'] and r['defect_kind'] == 'missing_base_case'
    )

    ml_valid = next(r for r in records
                    if r['record_id'] == 'axiom_ml:ml_list_sum:0:valid:none')
    ml_invalid = next(
        r for r in records
        if r['contrast_group_id'] == ml_valid['contrast_group_id']
        and not r['is_valid']
    )

    prolog_valid = next(r for r in records
                        if r['record_id'] == 'axiom_prolog:prolog_append_det:0:valid:none')
    # The variant 0 invalid is a renamed predicate which won't share the contrast
    # group with the valid form's query; pick a clean within-group invalid.
    prolog_invalid_candidates = [
        r for r in records
        if r['contrast_group_id'] == prolog_valid['contrast_group_id']
        and not r['is_valid']
    ]
    prolog_invalid = prolog_invalid_candidates[0]

    results: dict[str, AxiomMegaDoc] = {}

    # Latent diagnostics
    results['latent_scheme']  = build_latent_diagnostic_scheme(scheme_valid, scheme_invalid)
    results['latent_ml']      = build_latent_diagnostic_ml(ml_valid, ml_invalid)
    results['latent_prolog']  = build_latent_diagnostic_prolog(prolog_valid, prolog_invalid)

    # Runtime traces
    results['trace_scheme']  = build_runtime_trace(scheme_valid, 'scheme', run_scheme)
    results['trace_ml']      = build_runtime_trace(ml_valid, 'ml', run_ml)
    results['trace_prolog']  = build_runtime_trace(prolog_valid, 'prolog', run_prolog)

    # Write files
    out_dir.mkdir(parents=True, exist_ok=True)
    megadocs_dir = out_dir / 'megadocs'
    megadocs_dir.mkdir(exist_ok=True)
    rendered_files: dict[str, Path] = {}

    summary: dict[str, Any] = {
        'corpus_version': 'v0.9D',
        'records_loaded': len(records),
        'megadocs': {},
    }

    for key, md in results.items():
        text = render_megadoc(md)
        # Round-trip
        parsed = parse_rendered(text)
        rt_ok = (
            len(parsed) == len(md.segments)
            and all(p['content'] == s.content
                    for p, s in zip(parsed, md.segments))
        )
        fname = f'{key}.md'
        path = megadocs_dir / fname
        path.write_text(text)
        rendered_files[key] = path
        summary['megadocs'][key] = {
            'megadoc_id': md.megadoc_id,
            'construction': md.construction,
            'language_set': md.language_set,
            'record_ids': md.record_ids,
            'contrast_group_ids': md.contrast_group_ids,
            'split': md.split,
            'segment_count': len(md.segments),
            'token_estimate': md.token_estimate,
            'validation': md.validation,
            'render_parse_round_trip_ok': rt_ok,
            'file': f'megadocs/{fname}',
        }

    (out_dir / 'summary.json').write_text(json.dumps(summary, indent=2))
    return summary


if __name__ == '__main__':
    out = Path('./output')
    summary = build_all(out)
    print(json.dumps(summary, indent=2))
