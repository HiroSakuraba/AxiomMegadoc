"""AxiomMegaDoc v0.11 builders against v0.9D corpus bundle.

Reads records directly from the v0.9D ledger.jsonl rather than invoking the
generator (which calls runtime lanes per record and times out).

Implements two v0.11 megadoc families:
  - latent_diagnostic   (paper-aligned: source split + rationale + suffix)
  - runtime_trace       (independently motivated: source + execution result)

Records are simple dicts loaded from the ledger.  Field access is by key.
"""
from __future__ import annotations
import hashlib
import json
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Iterable

V09D_LEDGER = Path(__file__).parent.parent / 'source-corpus' / 'axiom_v09d_ledger.jsonl'


# ── load v0.9D records ────────────────────────────────────────────────────────

def load_records() -> list[dict]:
    records: list[dict] = []
    with V09D_LEDGER.open() as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


# ── megadoc dataclasses ───────────────────────────────────────────────────────

@dataclass
class MegaDocSegment:
    segment_id: str
    segment_type: str
    language: str
    record_id: str | None
    rationale_template_id: str | None
    content: str
    provenance: str
    trust_level: str


@dataclass
class AxiomMegaDoc:
    megadoc_id: str
    construction: str
    split: str
    record_ids: list[str]
    contrast_group_ids: list[str]
    language_set: list[str]
    segments: list[MegaDocSegment]
    rendered_text: str = ''
    token_estimate: int = 0
    validation: dict = field(default_factory=dict)


# ── deterministic extractors (provenance: extractor) ──────────────────────────

def split_scheme_at_recursive_boundary(canonical_source: str) -> tuple[str, str]:
    """Split a Scheme (define ... (if (null? xs) BASE RECURSIVE)) just after BASE.

    The byte-equality invariant: prefix + suffix == canonical_source exactly.
    """
    src = canonical_source
    m = re.search(r'\(if \(null\? [^)]+\)\n(\s+)([^\n]+)\n', src)
    if not m:
        raise ValueError('no recognisable (if (null? ...) ...) base case')
    boundary = m.end()
    prefix, suffix = src[:boundary], src[boundary:]
    assert prefix + suffix == src, 'split must be byte-equal under concat'
    return prefix, suffix


def extract_scheme_facts(record: dict) -> dict[str, str]:
    src = record['canonical_source']
    facts: dict[str, str] = {}
    m = re.search(r'\(define \(([a-z][A-Za-z0-9_]*)\s+(\w+)', src)
    if m:
        facts['function_name'] = m.group(1)
        facts['primary_argument'] = m.group(2)
    if '(@recursive structural)' in src:
        facts['recursive_annotation'] = '(@recursive structural)'
    elif '(@recursive none)' in src:
        facts['recursive_annotation'] = '(@recursive none)'
    if '(@effect pure)' in src:
        facts['effect_annotation'] = '(@effect pure)'
    if '(null?' in src:
        facts['base_predicate'] = '(null? xs)'
    return facts


# ── rationale template registry ───────────────────────────────────────────────

RATIONALE_TEMPLATES: dict[str, dict[str, Any]] = {
    'scheme_structural_recursion_obligation_v01': {
        'language': 'scheme',
        'applies_to_families': [
            'scheme_list_sum', 'scheme_list_product', 'scheme_list_length',
            'scheme_count_positive', 'scheme_running_sum',
        ],
        'required_facts': ['function_name', 'primary_argument',
                           'recursive_annotation', 'base_predicate'],
        'text': (
            'The {recursive_annotation} annotation creates an obligation: every '
            'recursive call to {function_name} must apply the function to a '
            'syntactic subterm of {primary_argument}. The base case below '
            'tests {base_predicate} — at the moment this branch fires, '
            '{primary_argument} is empty and {function_name} must return the '
            'identity element of the combining operator below.'
        ),
    },
}


def fill_rationale(template_id: str, facts: dict[str, str]) -> str:
    spec = RATIONALE_TEMPLATES[template_id]
    missing = [k for k in spec['required_facts'] if k not in facts]
    if missing:
        raise ValueError(f'template {template_id} missing facts: {missing}')
    return spec['text'].format(**facts)


def validate_rationale_facts(rationale: str, required_facts: list[str],
                             facts: dict[str, str]) -> bool:
    return all(facts[k] in rationale for k in required_facts)


# ── builder: latent_diagnostic ────────────────────────────────────────────────

REPAIR_TEXT = {
    'missing_base_case':       'Replace `#f` with `(null? xs)` — the structural '
                                'base predicate that must hold when the recursion '
                                'reaches the empty list.',
    'banned_mutation':         'Remove the `(set! ...)` form. AxiomScheme bans '
                                'mutation; effect annotation is `pure`.',
    'bad_effect_annotation':   'Restore `(@effect pure)` — the function performs '
                                'no I/O and the effect annotation must match.',
    'non_decreasing_recursion':'Replace the recursive argument with `(cdr xs)` '
                                'so the structural recursion contract is honoured.',
    'bad_recursive_annotation':'Restore `(@recursive structural)` — the function '
                                'recurses on a strict subterm of its argument.',
    'bad_resource_annotation': 'Restore the matching resource annotation.',
    'semantic_mismatch':       'Restore the original combining operator and '
                                'base value to match the family\'s semantic spec.',
}


def build_latent_diagnostic(valid: dict, invalid: dict) -> AxiomMegaDoc:
    if valid['language'] != 'axiom_scheme':
        raise NotImplementedError('latent_diagnostic only for scheme in v0.11')
    if valid['contrast_group_id'] != invalid['contrast_group_id']:
        raise ValueError('valid and invalid must share contrast group')
    if valid['split_group_key'] != invalid['split_group_key']:
        raise ValueError('split safety: records must share split_group_key')

    facts = extract_scheme_facts(valid)
    template_id = 'scheme_structural_recursion_obligation_v01'
    rationale = fill_rationale(template_id, facts)
    spec = RATIONALE_TEMPLATES[template_id]
    if not validate_rationale_facts(rationale, spec['required_facts'], facts):
        raise ValueError('rationale fact validation failed')

    prefix, suffix = split_scheme_at_recursive_boundary(valid['canonical_source'])

    repair_text = REPAIR_TEXT.get(invalid['defect_kind'],
                                   'See diagnostic for the required correction.')

    expected_str = json.dumps(valid['expected_output']['value'],
                              separators=(',', ':'))

    segments = [
        MegaDocSegment('S1', 'task', 'scheme', None, None,
                       (f'Compute the sum of a list of exact integers using '
                        f'structural recursion in AxiomScheme. The function '
                        f'below is named {facts["function_name"]}.'),
                       'rationale_template', 'explanatory'),
        MegaDocSegment('S2', 'source', 'scheme',
                       valid['record_id'], None,
                       prefix.rstrip('\n'),
                       'record', 'canonical'),
        MegaDocSegment('S3', 'rationale', 'none',
                       valid['record_id'], template_id,
                       rationale,
                       'rationale_template', 'explanatory'),
        MegaDocSegment('S4', 'source', 'scheme',
                       valid['record_id'], None,
                       suffix.rstrip('\n'),
                       'record', 'canonical'),
        MegaDocSegment('S5', 'expected_io', 'none',
                       valid['record_id'], None,
                       (f'input: {valid["semantic"]["input_expr"]}\n'
                        f'expected_value_json: {expected_str}'),
                       'extractor', 'extracted'),
        MegaDocSegment('S6', 'invalid_mutation', 'scheme',
                       invalid['record_id'], None,
                       invalid['canonical_source'],
                       'record', 'canonical'),
        MegaDocSegment('S7', 'diagnostic', 'none',
                       invalid['record_id'], None,
                       ', '.join(invalid['diagnostic_codes']),
                       'record', 'checked'),
        MegaDocSegment('S8', 'repair', 'none',
                       invalid['record_id'], None,
                       repair_text,
                       'rationale_template', 'explanatory'),
    ]

    cg = valid['contrast_group_id']
    md_id = 'md_' + hashlib.sha256(
        f'latent_diagnostic:{cg}'.encode()).hexdigest()[:12]

    valid_split = valid.get('split', 'train')
    invalid_split = invalid.get('split', 'train')

    return AxiomMegaDoc(
        megadoc_id=md_id,
        construction='latent_diagnostic',
        split=valid_split,
        record_ids=[valid['record_id'], invalid['record_id']],
        contrast_group_ids=[cg],
        language_set=['scheme'],
        segments=segments,
        validation={
            'all_records_same_split': valid_split == invalid_split,
            'all_canonical_sources_byte_equal':
                segments[1].content + '\n' + segments[3].content
                == valid['canonical_source'],
            'all_record_refs_resolve': True,
            'no_unchecked_source':
                all(s.trust_level == 'canonical'
                    for s in segments
                    if s.segment_type in ('source', 'invalid_mutation')),
            'rationale_template_ids_known':
                all((s.rationale_template_id in RATIONALE_TEMPLATES)
                    or (s.rationale_template_id is None)
                    for s in segments),
        },
    )


# ── builder: runtime_trace ────────────────────────────────────────────────────

def discover_guile() -> str | None:
    return shutil.which('guile')


def execute_scheme_record(record: dict) -> dict[str, Any]:
    """Run a Scheme record through Guile; strip annotation forms first."""
    exe = discover_guile()
    if exe is None:
        return {'status': 'skipped', 'reason': 'guile_not_on_path'}

    src = record['canonical_source']
    # Strip annotation forms: (@effect ...), (@resource ...), (@recursive ...)
    stripped = re.sub(r'\(@(?:effect|resource|recursive|higher-order)[^)]*\)\s*',
                      '', src)
    entry = record['semantic']['entry']
    input_expr = record['semantic']['input_expr']
    program = stripped + f'\n(write ({entry} {input_expr}))\n(newline)\n'

    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / 'prog.scm'
        p.write_text(program, encoding='utf-8')
        proc = subprocess.run(
            [exe, '--no-auto-compile', str(p)],
            text=True, capture_output=True, timeout=5,
        )

    if proc.returncode != 0:
        return {'status': 'fail', 'stderr': proc.stderr[-500:]}

    stdout = proc.stdout.strip()
    return {'status': 'pass', 'stdout': stdout}


def build_runtime_trace(record: dict) -> AxiomMegaDoc:
    if record['language'] != 'axiom_scheme':
        raise NotImplementedError('demo: scheme only')
    if not record['is_valid']:
        raise ValueError('runtime_trace requires a valid record')
    if not record['semantic'].get('guile_executable'):
        raise ValueError('record not marked guile_executable')

    lane = execute_scheme_record(record)
    if lane.get('status') != 'pass':
        raise RuntimeError(f'lane execution did not pass: {lane}')

    expected = record['expected_output']['value']
    expected_str = json.dumps(expected, separators=(',', ':'))

    # Best-effort observed JSON: parse stdout as integer for int-typed expected
    observed_str = lane['stdout']
    if expected.get('type') == 'int':
        try:
            observed_json = {'type': 'int', 'value': int(observed_str)}
            observed_str_out = json.dumps(observed_json, separators=(',', ':'))
        except ValueError:
            observed_str_out = json.dumps({'type': 'string', 'value': observed_str})
    else:
        observed_str_out = json.dumps({'type': 'string', 'value': observed_str})

    segments = [
        MegaDocSegment('S1', 'task', 'scheme', None, None,
                       'Execute the AxiomScheme function and observe its output '
                       'on a concrete input. Lane: Guile.',
                       'rationale_template', 'explanatory'),
        MegaDocSegment('S2', 'source', 'scheme',
                       record['record_id'], None,
                       record['canonical_source'],
                       'record', 'canonical'),
        MegaDocSegment('S3', 'expected_io', 'none',
                       record['record_id'], None,
                       (f'input_expr: {record["semantic"]["input_expr"]}\n'
                        f'function_call: ({record["semantic"]["entry"]} '
                        f'{record["semantic"]["input_expr"]})'),
                       'extractor', 'extracted'),
        MegaDocSegment('S4', 'runtime_result', 'none',
                       record['record_id'], None,
                       (f'lane: guile\n'
                        f'status: pass\n'
                        f'stdout: {lane["stdout"]}\n'
                        f'observed_value_json: {observed_str_out}\n'
                        f'expected_value_json: {expected_str}'),
                       'extractor', 'checked'),
    ]

    md_id = 'md_' + hashlib.sha256(
        f'runtime_trace:{record["record_id"]}'.encode()).hexdigest()[:12]

    return AxiomMegaDoc(
        megadoc_id=md_id,
        construction='runtime_trace',
        split=record.get('split', 'train'),
        record_ids=[record['record_id']],
        contrast_group_ids=[record['contrast_group_id']],
        language_set=['scheme'],
        segments=segments,
        validation={
            'all_records_same_split': True,
            'all_canonical_sources_byte_equal':
                segments[1].content == record['canonical_source'],
            'all_record_refs_resolve': True,
            'no_unchecked_source': True,
            'rationale_template_ids_known': True,
        },
    )


# ── render and round-trip parse ───────────────────────────────────────────────

def render_megadoc(md: AxiomMegaDoc) -> str:
    lines = [
        f'<AXIOM_MEGADOC id="{md.megadoc_id}" construction="{md.construction}" '
        f'split="{md.split}" languages="{",".join(md.language_set)}" '
        f'corpus="v0.9D">',
        '',
    ]
    for seg in md.segments:
        attrs = (f'type="{seg.segment_type}" trust="{seg.trust_level}" '
                 f'provenance="{seg.provenance}"')
        if seg.record_id:
            attrs += f' record_id="{seg.record_id}"'
        if seg.rationale_template_id:
            attrs += f' template="{seg.rationale_template_id}"'
        lines.append(f'<SEGMENT {attrs}>')
        if seg.language == 'scheme' and seg.segment_type in ('source', 'invalid_mutation'):
            lines.append('```scheme')
            lines.append(seg.content)
            lines.append('```')
        else:
            lines.append(seg.content)
        lines.append('</SEGMENT>')
        lines.append('')
    lines.append('</AXIOM_MEGADOC>')
    text = '\n'.join(lines)
    md.rendered_text = text
    md.token_estimate = len(text.split())
    return text


_SEG_OPEN = re.compile(r'<SEGMENT ([^>]+)>')
_SEG_ATTR = re.compile(r'(\w+)="([^"]*)"')

def parse_rendered(text: str) -> list[dict]:
    segments: list[dict] = []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        m = _SEG_OPEN.match(lines[i])
        if not m:
            i += 1
            continue
        attrs = dict(_SEG_ATTR.findall(m.group(1)))
        body: list[str] = []
        i += 1
        while i < len(lines) and lines[i] != '</SEGMENT>':
            body.append(lines[i])
            i += 1
        if body and body[0] == '```scheme':
            body = body[1:]
            if body and body[-1] == '```':
                body = body[:-1]
        segments.append({'attrs': attrs, 'content': '\n'.join(body)})
    return segments


# ── demo ──────────────────────────────────────────────────────────────────────

def main():
    records = load_records()
    print(f'loaded {len(records)} records from v0.9D ledger')

    # Find a Scheme list_sum valid record paired with its missing_base_case invalid.
    # In v0.9D variant 9 carries the missing_base_case defect for scheme_list_sum.
    valid = next(r for r in records
                 if r['template_id'] == 'scheme_list_sum'
                 and r['record_id'].endswith(':9:valid:none'))
    invalid = next(r for r in records
                   if r['template_id'] == 'scheme_list_sum'
                   and not r['is_valid']
                   and r['contrast_group_id'] == valid['contrast_group_id']
                   and r['defect_kind'] == 'missing_base_case')

    print(f'\nvalid:   {valid["record_id"]}')
    print(f'invalid: {invalid["record_id"]} (defect={invalid["defect_kind"]})')
    print(f'shared contrast_group: {valid["contrast_group_id"]}')
    print(f'split (both): {valid["split"]}')

    md_latent = build_latent_diagnostic(valid, invalid)
    rendered_latent = render_megadoc(md_latent)

    md_trace = build_runtime_trace(valid)
    rendered_trace = render_megadoc(md_trace)

    parsed_latent = parse_rendered(rendered_latent)
    rt_latent = (
        len(parsed_latent) == len(md_latent.segments)
        and all(p['content'] == s.content
                for p, s in zip(parsed_latent, md_latent.segments))
    )
    parsed_trace = parse_rendered(rendered_trace)
    rt_trace = (
        len(parsed_trace) == len(md_trace.segments)
        and all(p['content'] == s.content
                for p, s in zip(parsed_trace, md_trace.segments))
    )

    out_dir = Path('./output_scheme_only')
    out_dir.mkdir(exist_ok=True)
    (out_dir / 'example_latent_diagnostic.md').write_text(rendered_latent)
    (out_dir / 'example_runtime_trace.md').write_text(rendered_trace)

    summary = {
        'corpus_version': 'v0.9D',
        'records_loaded': len(records),
        'latent_diagnostic': {
            'megadoc_id': md_latent.megadoc_id,
            'construction': md_latent.construction,
            'split': md_latent.split,
            'record_ids': md_latent.record_ids,
            'segment_count': len(md_latent.segments),
            'token_estimate': md_latent.token_estimate,
            'validation': md_latent.validation,
            'render_parse_round_trip_ok': rt_latent,
        },
        'runtime_trace': {
            'megadoc_id': md_trace.megadoc_id,
            'construction': md_trace.construction,
            'split': md_trace.split,
            'record_ids': md_trace.record_ids,
            'segment_count': len(md_trace.segments),
            'token_estimate': md_trace.token_estimate,
            'validation': md_trace.validation,
            'render_parse_round_trip_ok': rt_trace,
        },
    }
    (out_dir / 'summary.json').write_text(json.dumps(summary, indent=2))
    return summary, rendered_latent, rendered_trace


if __name__ == '__main__':
    summary, rl, rt = main()
    print('\n=== SUMMARY ===')
    print(json.dumps(summary, indent=2))
    print('\n=== example_latent_diagnostic.md ===')
    print(rl)
    print('\n=== example_runtime_trace.md ===')
    print(rt)
