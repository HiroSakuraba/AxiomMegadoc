# Axiom Multilingual Corpus v0.9D — Release Notes

v0.9D is a cleanup release candidate.

## Summary

- Uses v0.9B as base.
- Ports useful v0.9C families.
- Removes v0.9C’s mandatory `swipl` generation dependency.
- Updates tests to target the active v0.9D generator.
- Regenerates a fresh corpus bundle.

## Validation

```text
12/12 tests passed
520 records
180 Scheme / 160 ML / 180 Prolog
260 valid / 260 invalid
release_status: pass
consistency: pass
shortcut rejection reasons: 0
exact duplicates: 0
```

## New families

- `scheme_eval_arith`
- `prolog_dcg_ab`
- `prolog_dcg_run`

## Known limitations

- Runtime lanes were skipped in this environment because Guile, SWI-Prolog, and MLton are not installed.
- ML remains parser-backed but not yet compiler-backed.
- Prolog FINITE-N semantic validation should be checked against SWI-Prolog in v1.0.
