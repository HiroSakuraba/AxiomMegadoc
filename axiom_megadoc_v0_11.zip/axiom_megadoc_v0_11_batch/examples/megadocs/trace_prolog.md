<AXIOM_MEGADOC id="md_5613f8a2b15f" construction="runtime_trace" split="train" languages="prolog" corpus="v0.9D">

<SEGMENT type="task" trust="explanatory" provenance="rationale_template">
Resolve the AxiomProlog query and collect all solutions. Lane: SWI-Prolog.
</SEGMENT>

<SEGMENT type="source" trust="canonical" provenance="record" record_id="axiom_prolog:prolog_append_det:0:valid:none">
```prolog
%!pappend_det0(+Left,+Right,-Out).
pappend_det0([],Right,Right).
pappend_det0([Head|Tail],Right,[Head|Out]) :- pappend_det0(Tail,Right,Out).
```
</SEGMENT>

<SEGMENT type="expected_io" trust="extracted" provenance="extractor" record_id="axiom_prolog:prolog_append_det:0:valid:none">
query: pappend_det0([a,b],[c],Out)
driver: findall + write_canonical
</SEGMENT>

<SEGMENT type="runtime_result" trust="checked" provenance="extractor" record_id="axiom_prolog:prolog_append_det:0:valid:none">
lane: prolog
status: pass
stdout: 1
Out=[a,b,c]
---
expected_value_json: [{"Out":{"items":[{"type":"atom","value":"a"},{"type":"atom","value":"b"},{"type":"atom","value":"c"}],"type":"list"}}]
</SEGMENT>

</AXIOM_MEGADOC>