<AXIOM_MEGADOC id="md_88652c73f56d" construction="runtime_trace" split="train" languages="ml" corpus="v0.9D">

<SEGMENT type="task" trust="explanatory" provenance="rationale_template">
Compile and run the AxiomML function on a concrete input. Lane: MLton.
</SEGMENT>

<SEGMENT type="source" trust="canonical" provenance="record" record_id="axiom_ml:ml_list_sum:0:valid:none">
```sml
(* @effect: pure *)
(* @recursive: structural *)
fun mlistsum0 (xs:int list) : int =
  case xs of [] => 0 | h::t => h+mlistsum0 t
```
</SEGMENT>

<SEGMENT type="expected_io" trust="extracted" provenance="extractor" record_id="axiom_ml:ml_list_sum:0:valid:none">
input: [1,2,3]
compilation: mlton
</SEGMENT>

<SEGMENT type="runtime_result" trust="checked" provenance="extractor" record_id="axiom_ml:ml_list_sum:0:valid:none">
lane: ml
status: pass
stdout: 6
expected_value_json: {"type":"int","value":6}
</SEGMENT>

</AXIOM_MEGADOC>